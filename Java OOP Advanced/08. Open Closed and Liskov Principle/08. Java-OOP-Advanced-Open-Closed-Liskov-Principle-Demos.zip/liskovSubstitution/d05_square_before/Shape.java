package liskovSubstitution.d05_square_before;

public abstract class Shape {
    public abstract double area();
}
