package liskovSubstitution.d09_movement_before.contracts;

public interface Movable {
    void move();
    void rotate();
    void translate();
}
