package liskovSubstitution.d10_movement_after.contracts;

public interface Rotatable extends Movable {
    void rotate();
}
