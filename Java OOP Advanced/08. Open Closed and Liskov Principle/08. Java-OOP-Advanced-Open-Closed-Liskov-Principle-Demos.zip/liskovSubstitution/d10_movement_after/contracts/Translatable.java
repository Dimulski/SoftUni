package liskovSubstitution.d10_movement_after.contracts;

public interface Translatable extends Movable {
    void translate();
}
