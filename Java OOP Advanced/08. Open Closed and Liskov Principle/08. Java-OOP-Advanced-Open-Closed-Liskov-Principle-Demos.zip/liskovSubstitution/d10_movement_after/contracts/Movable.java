package liskovSubstitution.d10_movement_after.contracts;

public interface Movable {
    void move();
}
