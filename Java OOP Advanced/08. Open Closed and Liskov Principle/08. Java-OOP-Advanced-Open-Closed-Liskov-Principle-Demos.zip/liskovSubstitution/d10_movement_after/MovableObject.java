package liskovSubstitution.d10_movement_after;

import liskovSubstitution.d10_movement_after.contracts.Movable;

public abstract class MovableObject implements Movable {

    public abstract void translate();

    public abstract void rotate();

    @Override
    public void move() {
        this.translate();
        this.rotate();
    }
}
