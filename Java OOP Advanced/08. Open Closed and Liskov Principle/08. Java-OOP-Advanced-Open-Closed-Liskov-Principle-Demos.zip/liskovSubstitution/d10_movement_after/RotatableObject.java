package liskovSubstitution.d10_movement_after;

import liskovSubstitution.d10_movement_after.contracts.Rotatable;

public abstract class RotatableObject implements Rotatable {

    public abstract void rotate();

    @Override
    public void move() {
        this.rotate();
    }
}
