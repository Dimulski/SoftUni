package liskovSubstitution.d06_square_after;

public abstract class Shape {
    public abstract double area();
}
