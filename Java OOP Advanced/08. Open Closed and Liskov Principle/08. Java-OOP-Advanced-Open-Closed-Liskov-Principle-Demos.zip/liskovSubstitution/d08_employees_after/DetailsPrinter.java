package liskovSubstitution.d08_employees_after;

public class DetailsPrinter {

}
