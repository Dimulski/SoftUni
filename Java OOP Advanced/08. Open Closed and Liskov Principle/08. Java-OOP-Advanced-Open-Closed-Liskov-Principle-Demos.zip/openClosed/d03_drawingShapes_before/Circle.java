package openClosed.d03_drawingShapes_before;

import openClosed.d03_drawingShapes_before.contracts.Shape;

public class Circle implements Shape {
}
