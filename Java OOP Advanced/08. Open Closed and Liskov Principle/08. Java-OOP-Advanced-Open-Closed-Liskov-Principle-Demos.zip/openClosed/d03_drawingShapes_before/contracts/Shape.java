package openClosed.d03_drawingShapes_before.contracts;

public interface Shape {
}
