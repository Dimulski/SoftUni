package openClosed.d03_drawingShapes_before.contracts;

public interface Drawer {
    void draw(Shape shape);
}
