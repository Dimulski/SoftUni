package openClosed.d04_drawingShapes_after.contracts;

public interface Shape {

}
