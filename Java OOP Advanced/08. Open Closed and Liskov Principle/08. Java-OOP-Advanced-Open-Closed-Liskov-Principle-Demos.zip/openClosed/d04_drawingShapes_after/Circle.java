package openClosed.d04_drawingShapes_after;

public class Circle {

}
