package openClosed.d02_fileStream_after.contracts;

public interface Streamable {
    int getLength();
    int getBytesSent();
}
