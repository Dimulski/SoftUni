package problem2KingsGambit.commands.contracts;

public interface Executable {

    String execute();
}
