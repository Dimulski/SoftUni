package problem2KingsGambit.core.contracts;

import java.io.IOException;

public interface Engine {

    void run() throws IOException;
}
