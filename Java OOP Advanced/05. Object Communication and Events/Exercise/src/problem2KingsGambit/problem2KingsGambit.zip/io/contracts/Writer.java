package problem2KingsGambit.io.contracts;

public interface Writer {

    void write(Object message);
}
