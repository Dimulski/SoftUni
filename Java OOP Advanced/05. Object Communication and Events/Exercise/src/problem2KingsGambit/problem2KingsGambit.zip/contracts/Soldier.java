package problem2KingsGambit.contracts;

public interface Soldier extends Nameable, Killable, Observer {

}
