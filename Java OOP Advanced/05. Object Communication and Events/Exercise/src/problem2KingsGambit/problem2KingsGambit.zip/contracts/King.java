package problem2KingsGambit.contracts;

public interface King extends Nameable, Attackable {

}
