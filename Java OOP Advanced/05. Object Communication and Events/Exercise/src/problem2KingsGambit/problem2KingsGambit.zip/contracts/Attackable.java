package problem2KingsGambit.contracts;

public interface Attackable extends Observable {

    String respondToAttack();
}
