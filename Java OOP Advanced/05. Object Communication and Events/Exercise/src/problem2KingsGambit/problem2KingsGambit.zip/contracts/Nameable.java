package problem2KingsGambit.contracts;

public interface Nameable {

    String getName();
}
