package d2.genericInterfaces;

public class Employee extends Person {
    public Employee(String name) {
        super(name);
    }
}
