package d4.typeErasure;

public class TypeErasure<T> {

    public void f(Object obj) {
//        if (obj instanceof T) {}
//        T[] array = new T[1];
//        T newInstance = new T();
    }
}
