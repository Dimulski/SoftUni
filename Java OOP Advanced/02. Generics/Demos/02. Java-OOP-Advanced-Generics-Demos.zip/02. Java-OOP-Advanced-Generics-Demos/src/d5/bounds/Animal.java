package d5.bounds;

public interface Animal {
    public void eat();
}
