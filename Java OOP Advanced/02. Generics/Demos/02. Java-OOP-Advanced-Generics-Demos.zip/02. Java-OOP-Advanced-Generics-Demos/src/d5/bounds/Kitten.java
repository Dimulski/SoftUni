package d5.bounds;

public class Kitten extends Cat {
}
