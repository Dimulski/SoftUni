package d6.wildcards;

public class Dog extends Animal {

}
