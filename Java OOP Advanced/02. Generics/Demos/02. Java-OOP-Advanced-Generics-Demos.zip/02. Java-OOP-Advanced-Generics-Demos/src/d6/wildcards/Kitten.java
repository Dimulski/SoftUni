package d6.wildcards;

public class Kitten extends Cat {

}
