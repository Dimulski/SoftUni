package d6.wildcards;

public class Cat extends Animal {

}
