package Problem5BorderControl;

interface Citizen extends Identifiable {

    String getName();

    Integer getAge();
}
