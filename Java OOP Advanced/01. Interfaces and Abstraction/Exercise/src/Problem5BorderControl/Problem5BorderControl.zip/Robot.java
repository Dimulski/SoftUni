package Problem5BorderControl;

interface Robot extends Identifiable {

    String getModel();
}
