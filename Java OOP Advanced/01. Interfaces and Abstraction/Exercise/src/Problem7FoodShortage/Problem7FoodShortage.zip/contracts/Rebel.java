package Problem7FoodShortage.contracts;

public interface Rebel extends Nameable, Buyer {

    Integer getAge();

    String getGroup();
}
