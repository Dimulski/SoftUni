package Problem7FoodShortage.contracts;

public interface Birthable {

    String getBirthday();
}
