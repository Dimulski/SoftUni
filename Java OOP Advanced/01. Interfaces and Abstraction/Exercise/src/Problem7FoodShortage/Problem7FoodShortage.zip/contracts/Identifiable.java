package Problem7FoodShortage.contracts;

interface Identifiable {

    String getId();
}
