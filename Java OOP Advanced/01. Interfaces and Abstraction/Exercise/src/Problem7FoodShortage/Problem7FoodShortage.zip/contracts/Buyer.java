package Problem7FoodShortage.contracts;

public interface Buyer {

    void buyFood();

    Integer getFoodAmount();
}
