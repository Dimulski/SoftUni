package Problem7FoodShortage.contracts;

interface Nameable {

    String getName();
}
