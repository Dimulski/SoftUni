package Problem7FoodShortage.contracts;

public interface Citizen extends Birthable, Nameable, Identifiable, Buyer {

    Integer getAge();
}
