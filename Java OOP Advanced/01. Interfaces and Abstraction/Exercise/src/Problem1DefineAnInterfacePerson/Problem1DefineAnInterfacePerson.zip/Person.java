package Problem1DefineAnInterfacePerson;

public interface Person {

    String getName();

    Integer getAge();
}
