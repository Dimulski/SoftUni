package Problem9CollectionHierarchy.contracts;

public interface Addable {
    int add(String item);
}
