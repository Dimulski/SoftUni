package Problem9CollectionHierarchy.contracts;

public interface Used { // not the best of names
    int getSize();
}
