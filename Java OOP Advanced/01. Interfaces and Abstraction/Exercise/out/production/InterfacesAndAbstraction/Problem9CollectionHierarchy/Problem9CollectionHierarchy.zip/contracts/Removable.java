package Problem9CollectionHierarchy.contracts;

public interface Removable {
    String remove();
}
