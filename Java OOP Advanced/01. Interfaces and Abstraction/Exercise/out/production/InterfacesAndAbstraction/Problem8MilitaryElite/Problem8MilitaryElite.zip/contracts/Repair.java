package Problem8MilitaryElite.contracts;

public interface Repair {

    String getPartName();

    Integer getHoursWorked();
}
