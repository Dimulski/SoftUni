package Problem8MilitaryElite.enums;

public enum Corp {
    Airforces, Marines
}
