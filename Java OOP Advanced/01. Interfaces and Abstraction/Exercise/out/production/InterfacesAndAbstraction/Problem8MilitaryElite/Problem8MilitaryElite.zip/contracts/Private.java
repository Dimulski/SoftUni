package Problem8MilitaryElite.contracts;

public interface Private extends Soldier {

    Double getSalary();
}
