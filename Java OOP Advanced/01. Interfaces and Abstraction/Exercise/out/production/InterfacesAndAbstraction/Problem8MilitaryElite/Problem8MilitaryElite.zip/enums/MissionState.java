package Problem8MilitaryElite.enums;

public enum MissionState {
    inProgress, Finished
}
