package Problem8MilitaryElite.contracts;

public interface Spy extends Soldier {

    Integer getCodeNumber();
}
