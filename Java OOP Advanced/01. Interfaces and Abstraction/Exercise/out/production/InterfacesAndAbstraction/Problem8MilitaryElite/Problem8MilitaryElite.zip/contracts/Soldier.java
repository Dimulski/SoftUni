package Problem8MilitaryElite.contracts;

public interface Soldier {

    Integer getId();

    String getFirstName();

    String getLastName();
}
