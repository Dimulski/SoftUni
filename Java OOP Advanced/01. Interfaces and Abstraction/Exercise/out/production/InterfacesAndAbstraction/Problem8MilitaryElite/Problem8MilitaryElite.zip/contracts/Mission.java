package Problem8MilitaryElite.contracts;

import Problem8MilitaryElite.enums.MissionState;

public interface Mission {

    String getCodeName();

    MissionState getMissionState();
}
