package Problem8MilitaryElite.contracts;

import Problem8MilitaryElite.MissionState;

public interface Mission {

    String getCodeName();

    MissionState getMissionState();
}
