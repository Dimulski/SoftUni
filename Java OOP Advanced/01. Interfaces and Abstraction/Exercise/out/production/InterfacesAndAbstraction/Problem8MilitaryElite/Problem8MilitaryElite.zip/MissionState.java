package Problem8MilitaryElite;

public enum MissionState {
    inProgress, Finished
}
