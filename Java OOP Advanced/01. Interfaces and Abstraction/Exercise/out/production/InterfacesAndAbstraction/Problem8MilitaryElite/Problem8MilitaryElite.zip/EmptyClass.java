package Problem8MilitaryElite;

public class EmptyClass { // Because otherwise Judge can't compile :)
}
