package Problem8MilitaryElite.contracts;

import Problem8MilitaryElite.Corp;

public interface SpecialisedSoldier extends Private {

    Corp getCorps();
}
