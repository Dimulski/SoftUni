package Problem8MilitaryElite.contracts;

import Problem8MilitaryElite.enums.Corp;

public interface SpecialisedSoldier extends Private {

    Corp getCorps();
}
