package Problem8MilitaryElite;

public enum Corp { // Judge can't compile when it has to import enums :)
    Airforces, Marines
}
