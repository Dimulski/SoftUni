package Problem8MilitaryElite;

public enum Corp {
    Airforces, Marines
}
