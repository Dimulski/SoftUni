package Problem2MultipleImplementation;

interface Person { //  extends Birthable, Identifiable

    String getName();

    Integer getAge();
}
