package Problem2MultipleImplementation;

public interface Identifiable {

    String getId();
}
