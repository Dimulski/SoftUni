package Problem2MultipleImplementation;

public interface Birthable {

    String birthday();
}
