package main.bg.softuni.contracts;

public interface DirectoryCreator {

    void createDirectoryInCurrentFolder(String name);
}
