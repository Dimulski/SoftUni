package main.bg.softuni.contracts;

public interface DirectoryManager extends
        DirectoryChanger,
        DirectoryTraverser,
        DirectoryCreator{

}
