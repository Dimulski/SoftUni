package problem1ListyIterator;

interface ListyIterator {

    boolean move();

    boolean hasNext();

    void print();
}
