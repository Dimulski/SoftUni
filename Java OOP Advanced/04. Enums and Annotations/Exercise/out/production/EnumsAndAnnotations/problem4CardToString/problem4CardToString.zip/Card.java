package problem4CardToString;

interface Card {

    Integer getPower();

    CardRank getCardRank();

    CardSuit getCardSuit();
}
