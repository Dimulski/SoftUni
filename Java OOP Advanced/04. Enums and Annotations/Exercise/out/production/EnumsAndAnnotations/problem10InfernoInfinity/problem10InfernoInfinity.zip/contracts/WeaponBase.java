package problem10InfernoInfinity.contracts;

public interface WeaponBase {

    Integer getMinDamage();

    Integer getMaxDamage();

    Gem[] getSockets();
}
