package problem10InfernoInfinity.models;

import problem10InfernoInfinity.contracts.CommandInterpreter;

public class CommandInterpreterImpl implements CommandInterpreter {

    @Override
    public void interpretCommand(String command) {

    }
}
