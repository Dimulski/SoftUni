package problem10InfernoInfinity.contracts;

public interface Database {

    void addWeapon(Weapon weapon);
    Weapon getWeapon(String name);
}
