package problem10InfernoInfinity.contracts;

public interface Gem {

    Integer getStrength();

    Integer getAgility();

    Integer getVitality();
}
