package problem10InfernoInfinity.contracts;

public interface Socket {

    Gem getContent();
}
