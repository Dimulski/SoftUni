package problem10InfernoInfinity.contracts;

public interface CommandInterpreter {

    void interpretCommand(String command);
}
