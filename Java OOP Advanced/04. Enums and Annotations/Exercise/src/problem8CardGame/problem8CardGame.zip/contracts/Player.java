package problem8CardGame.contracts;

import java.util.List;

public interface Player {

    String getName();

    List<Card> getHand();
}
