package bg.jwd.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebFilter(urlPatterns = "/pages/*")
public class SecurityFilter implements Filter {

	private static final String username = "admin";
	private static final String password = "1234";

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");

		if (username != null && password != null) {
			if (SecurityFilter.username.equals(username) && SecurityFilter.password.equals(password)) {
				((HttpServletRequest) request).getSession().setAttribute("username", username);
				((HttpServletResponse) response).sendRedirect("/FiltersHomework/pages/HomePage.jsp");
			} else {
				((HttpServletResponse) response).sendRedirect("/FiltersHomework/Login.jsp");
			}
		} else {
			username = (String) ((HttpServletRequest) request).getSession().getAttribute("username");

			if (username == null) {
				((HttpServletResponse) response).sendRedirect("/FiltersHomework/Login.jsp");
			}
		}

		chain.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
