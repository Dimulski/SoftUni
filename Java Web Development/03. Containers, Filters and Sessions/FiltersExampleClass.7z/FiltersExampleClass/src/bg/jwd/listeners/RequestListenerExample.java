package bg.jwd.listeners;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;

@WebListener
public class RequestListenerExample implements ServletRequestListener {

	@Override
	public void requestDestroyed(ServletRequestEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void requestInitialized(ServletRequestEvent event) {
		System.out.println("Request session: " + ((HttpServletRequest) event.getServletRequest()).getSession().getId());
		System.out.println("Address: " + event.getServletRequest().getLocalAddr());
	}

}
