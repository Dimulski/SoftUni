package bg.jwd.ejb;

import javax.ejb.Stateless;

@Stateless
public class StatelessHelloWorldImpl2 implements StatelessHelloWorld {

	@Override
	public String helloStatelessEjb() {
		return "New implementation";
	}
}
