package bg.jwd.ejb;

public interface SingletonBean {
	String singletonHelloWorld();
}
