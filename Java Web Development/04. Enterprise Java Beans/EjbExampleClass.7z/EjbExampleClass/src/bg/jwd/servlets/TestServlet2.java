package bg.jwd.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bg.jwd.ejb.SingletonBean;
import bg.jwd.ejb.StatefulHelloWorld;
import bg.jwd.ejb.StatelessHelloWorld;

@WebServlet("/TestServlet2")
public class TestServlet2 extends HttpServlet {

	private static final long serialVersionUID = 8476249670627148025L;

	@EJB(beanName = "StatelessHelloWorldImpl")
	private StatelessHelloWorld statelessHelloWorld;

	@EJB
	private StatefulHelloWorld statefulHelloWorld;

	@EJB
	private SingletonBean singletonBean;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.getWriter().println(statelessHelloWorld.helloStatelessEjb());
		response.getWriter().println(statefulHelloWorld.statefulHelloWorld());
		response.getWriter().println(singletonBean.singletonHelloWorld());
	}
}
