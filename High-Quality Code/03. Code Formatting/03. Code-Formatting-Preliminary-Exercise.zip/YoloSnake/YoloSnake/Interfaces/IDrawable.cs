﻿namespace YoloSnake.Interfaces {
    public interface IDrawable {
        void Draw(IDrawer drawer);
    }
}