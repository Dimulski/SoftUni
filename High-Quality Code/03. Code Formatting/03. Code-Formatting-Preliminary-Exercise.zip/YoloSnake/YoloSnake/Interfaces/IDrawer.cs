﻿namespace YoloSnake.Interfaces {
    public interface IDrawer {
        void DrawPoint(int 
            x, int 
            y, char 
            symbol
        );
    }
}