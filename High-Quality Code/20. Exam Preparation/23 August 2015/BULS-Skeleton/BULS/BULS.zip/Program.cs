﻿namespace buls
{
    using BangaloreUniversityLearningSystem.Core;

    public class Program
    {
        public static void Main()
        {
            var Engine = new BangaloreUniversityEngine();
            Engine.Run();
        }
    }
}