namespace Interfaces
{
    public interface IRepository
    {
    }
}