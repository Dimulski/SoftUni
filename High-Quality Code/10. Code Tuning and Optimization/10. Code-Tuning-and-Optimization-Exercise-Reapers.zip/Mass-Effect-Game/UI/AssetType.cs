﻿namespace FlyweightGame.UI
{
    public enum AssetType
    {
        Reaper
    }
}
