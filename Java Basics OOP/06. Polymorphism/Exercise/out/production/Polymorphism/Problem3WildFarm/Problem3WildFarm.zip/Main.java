package Problem3WildFarm;

import Problem3WildFarm.models.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String even;
        while (!(even = reader.readLine()).equals("End")) {
            String[] animalParams = even.split(" ");
            String[] foodParams = reader.readLine().split(" ");
            Food food = null;
            switch (foodParams[0]) {
                case "Vegetable":
                    food = new Vegetable(Integer.parseInt(foodParams[1]));
                    break;
                case "Meat":
                    food = new Meat(Integer.parseInt(foodParams[1]));
                    break;
            }
            try {
                switch (animalParams[0]) {
                    case "Cat":
                        Animal cat = new Cat(animalParams[0], animalParams[1],
                                Double.parseDouble(animalParams[2]), animalParams[3], animalParams[4]);
                        cat.makeSound();
                        cat.eat(food);
                        System.out.println(cat);
                        break;
                    case "Tiger":
                        Animal tiger = new Tiger(animalParams[0], animalParams[1],
                                Double.parseDouble(animalParams[2]), animalParams[3]);
                        tiger.makeSound();
                        tiger.eat(food);
                        System.out.println(tiger);
                        break;
                    case "Zebra":
                        Animal zebra = new Zebra(animalParams[0], animalParams[1],
                                Double.parseDouble(animalParams[2]), animalParams[3]);
                        zebra.makeSound();
                        zebra.eat(food);
                        System.out.println(zebra);
                        break;
                    case "Mouse":
                        Animal mouse = new Mouse(animalParams[0], animalParams[1],
                                Double.parseDouble(animalParams[2]), animalParams[3]);
                        mouse.makeSound();
                        mouse.eat(food);
                        System.out.println(mouse);
                        break;

                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
