package net.java.main.interfaces;

public interface InputReader {

    String readLine();

}
