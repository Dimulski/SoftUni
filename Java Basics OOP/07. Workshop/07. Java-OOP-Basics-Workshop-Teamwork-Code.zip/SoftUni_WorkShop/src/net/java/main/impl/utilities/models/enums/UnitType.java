package net.java.main.impl.utilities.models.enums;

public enum UnitType {
    Carrier,
    Marine
}
