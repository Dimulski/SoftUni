package net.java.main.interfaces;

public interface OutputWriter {

    void writeLine(String line);

    void writeLine(Object line);

}
