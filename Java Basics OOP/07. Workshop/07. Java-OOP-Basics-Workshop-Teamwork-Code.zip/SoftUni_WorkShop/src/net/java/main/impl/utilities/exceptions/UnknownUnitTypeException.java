package net.java.main.impl.utilities.exceptions;

public class UnknownUnitTypeException extends GameException{

    public UnknownUnitTypeException(String message) {
        super(message);
    }
}
