package net.java.main.impl.utilities.exceptions;

public class InvalidPositionException extends GameException {

    public InvalidPositionException(String message) {
        super(message);
    }
}
