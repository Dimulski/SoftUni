package net.java.main.impl.utilities.exceptions;

public class NotEnoughEnergyException extends GameException {

    public NotEnoughEnergyException(String message) {
        super(message);
    }
}
