package Problem6Animals.interfaces;

public interface ISoundProducible {
    String produceSound();
}
