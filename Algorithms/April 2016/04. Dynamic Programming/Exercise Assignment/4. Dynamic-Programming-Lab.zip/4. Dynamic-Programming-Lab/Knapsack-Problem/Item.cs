﻿namespace Knapsack_Problem
{
    public class Item
    {
        public int Weight { get; set; }

        public int Price { get; set; }
    }
}
