﻿namespace AStarAlgorithm
{
    using System;
    using System.Collections.Generic;

    public class AStar
    {
        private readonly char[,] map;

        public AStar(char[,] map)
        {
            this.map = map;
        }

        public List<int[]> FindShortestPath(int[] startCoords, int[] endCoords)
        {
            throw new NotImplementedException();
        }
    }
}
