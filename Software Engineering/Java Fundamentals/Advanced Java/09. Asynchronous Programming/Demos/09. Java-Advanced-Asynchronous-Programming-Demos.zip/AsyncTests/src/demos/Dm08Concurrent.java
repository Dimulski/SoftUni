package demos;

import java.util.ArrayList;
import java.util.List;

public class Dm08Concurrent {
    private static StringBuilder str = new StringBuilder();
//    static StringBuffer str = new StringBuffer();
//    static Queue<Integer> queue = new ConcurrentLinkedQueue<>();

    public static void main(String[] args) {
        List<Thread> threadList = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            Thread t = new Thread(() -> {
                for (int j = 0; j < 10; j++) {
                    str.append(j);
//                    queue.add(j);
                }
            });
            threadList.add(t);
            t.start();
        }

        for (Thread thread : threadList) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
//        System.out.println(queue.size());
        System.out.println(str.length());
    }
}
