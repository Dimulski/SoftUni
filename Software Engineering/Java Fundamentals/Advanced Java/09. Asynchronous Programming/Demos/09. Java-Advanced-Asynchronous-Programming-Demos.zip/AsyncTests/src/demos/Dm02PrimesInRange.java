package demos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Dm02PrimesInRange {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        printPrimesInRange(0, 999999);
        System.out.println("What should I do?");
        while (true) {
            String command = reader.readLine();
            if (command.equals("stop")) {
                // we want to stop the printPrimesInRange method and print all found until now
                // but HOW!?!?!?
            }
            else if (command.equals("exit")) {
                break;
            }
        }
    }

    private static void printPrimesInRange(int rangeFirst, int rangeLast) {
        List<Integer> primes = new ArrayList<>();
        for (int number = rangeFirst; number < rangeLast; number++) {
            boolean isPrime = true;
            for (int divider = 2; divider < number; divider++) {
                if (number % divider == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                primes.add(number);
            }
        }

        System.out.println(primes);
    }
}
