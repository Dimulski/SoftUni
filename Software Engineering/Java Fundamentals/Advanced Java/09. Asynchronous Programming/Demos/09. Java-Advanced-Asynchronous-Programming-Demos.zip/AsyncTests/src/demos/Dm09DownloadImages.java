package demos;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.Queue;

public class Dm09DownloadImages {
    private static void downloadImages() {
        while (true) {
            String urlString = imageQueue.poll();
            if (urlString == null) {
                break;
            }
            BufferedImage image;
            URL url;
            try {
                url = new URL(urlString);
                int lastSlashIndex = url.toString().lastIndexOf('/');
                String imgName = url.toString().substring(lastSlashIndex + 1) + ".jpg";
                System.out.println("Thread " + Thread.currentThread().getId() + " downloading " + imgName);
                image = ImageIO.read(url);
                File imageAsFile = new File("res/" + imgName);
                ImageIO.write(image, "jpg", imageAsFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    final static Queue<String> imageQueue = new ArrayDeque<>();

    public static void main(String[] args) {
        imageQueue.add("https://softuni.bg/companies/profile/logo/194");
        imageQueue.add("https://softuni.bg/companies/profile/logo/219");
        imageQueue.add("https://softuni.bg/companies/profile/logo/114");
        imageQueue.add("https://softuni.bg/companies/profile/logo/106");
        imageQueue.add("https://softuni.bg/companies/profile/logo/76");

        long startTime = System.nanoTime();
        downloadImages();
        System.out.println("Elapsed seconds: " + (System.nanoTime() - startTime) / 1000000000d);
    }
}
