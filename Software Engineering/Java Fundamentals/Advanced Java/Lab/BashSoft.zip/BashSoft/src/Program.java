import IO.InputReader;

import java.io.IOException;

public class Program {

    public static void main(String[] args) throws IOException {
        InputReader.readCommands();
    }
}
