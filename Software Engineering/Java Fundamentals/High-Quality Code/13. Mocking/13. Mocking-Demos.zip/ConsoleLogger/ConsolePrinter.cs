﻿namespace ConsoleLogger
{
    using System;

    public class ConsolePrinter
    {
        public void Print(string message)
        {
            Console.WriteLine(message);
        }
    }
}
