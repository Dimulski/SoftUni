﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DirectoryTraversal.Tests
{
    [TestClass]
    public class DIrectoryTraverserTests
    {
        [TestMethod]
        public void GetChildDirectories_ShouldReturnDirectoryNames()
        {
            // TODO: Apply the Inversion of Control principle 
            // and mock all external dependencies to DirectoryTraverser
            
        }
    }
}
