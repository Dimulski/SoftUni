﻿namespace ChangePreventers
{
    class Program
    {
        static void Main()
        {
            Application.Start();
        }
    }
}
