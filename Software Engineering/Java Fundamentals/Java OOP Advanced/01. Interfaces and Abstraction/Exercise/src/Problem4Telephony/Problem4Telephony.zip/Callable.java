package Problem4Telephony;

interface Callable {

    String makeCall(String phoneNumber);
}
