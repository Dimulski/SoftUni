package Problem4Telephony;

interface WebBrowsable {

    String browsWeb(String URL);
}
