package Problem6BirthdayCelebrations;

interface Nameable {

    String getName();
}
