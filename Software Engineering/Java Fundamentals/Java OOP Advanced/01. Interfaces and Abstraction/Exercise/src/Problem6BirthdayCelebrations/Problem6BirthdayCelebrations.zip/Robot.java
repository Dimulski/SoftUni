package Problem6BirthdayCelebrations;

interface Robot extends Identifiable {

    String getModel();
}
