package Problem6BirthdayCelebrations;

interface Citizen extends Birthable, Nameable, Identifiable {

    Integer getAge();
}
