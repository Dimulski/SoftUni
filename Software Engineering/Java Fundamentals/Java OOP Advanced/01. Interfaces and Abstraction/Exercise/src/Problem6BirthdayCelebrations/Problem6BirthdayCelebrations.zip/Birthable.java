package Problem6BirthdayCelebrations;

interface Birthable { // no such word

    String getBirthday();
}
