package Problem6BirthdayCelebrations;

interface Pet extends Birthable, Nameable {

}
