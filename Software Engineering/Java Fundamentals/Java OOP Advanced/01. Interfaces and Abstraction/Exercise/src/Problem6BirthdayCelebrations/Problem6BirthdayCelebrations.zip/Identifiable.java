package Problem6BirthdayCelebrations;

interface Identifiable {

    String getId();
}
