package Problem3Ferrari;

interface Car {

    String getDriver();

    String hitBreak();

    String stepOnTheGas();
}
