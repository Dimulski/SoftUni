package problem9TrafficLights;

interface TrafficLight {

    Light getLight();

    void changeLight();
}
