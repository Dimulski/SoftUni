package problem10InfernoInfinityV2.commands;

public interface Executable {

    String execute();
}
