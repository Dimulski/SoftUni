package problem10InfernoInfinityV2.enums;

public enum WeaponType {
    AXE,
    SWORD,
    KNIFE
}
