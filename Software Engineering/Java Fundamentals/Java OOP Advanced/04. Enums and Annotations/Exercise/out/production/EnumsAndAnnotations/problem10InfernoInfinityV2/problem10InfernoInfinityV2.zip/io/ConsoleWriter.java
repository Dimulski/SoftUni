package problem10InfernoInfinityV2.io;

public class ConsoleWriter implements Writer {

    @Override
    public void write(Object message) {
        System.out.println(message);
    }
}
