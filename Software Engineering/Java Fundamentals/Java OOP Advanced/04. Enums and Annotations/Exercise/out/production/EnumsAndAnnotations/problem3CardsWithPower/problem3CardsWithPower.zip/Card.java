package problem3CardsWithPower;

interface Card {

    Integer getPower();

    CardRank getCardRank();

    CardSuit getCardSuit();
}
