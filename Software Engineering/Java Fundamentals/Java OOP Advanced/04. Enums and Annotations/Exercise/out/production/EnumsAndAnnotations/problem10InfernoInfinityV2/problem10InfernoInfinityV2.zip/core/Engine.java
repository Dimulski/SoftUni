package problem10InfernoInfinityV2.core;

import java.io.IOException;

public interface Engine {

    void run() throws IOException;
}
