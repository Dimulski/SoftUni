package problem9TrafficLights;

enum Light {
    RED, GREEN, YELLOW
}
