package problem10InfernoInfinityV2.enums;

public enum GemType {
    RUBY,
    EMERALD,
    AMETHYST
}
