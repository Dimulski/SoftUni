package problem10InfernoInfinityV2.io;

public interface Writer {
    void write(Object message);
}
