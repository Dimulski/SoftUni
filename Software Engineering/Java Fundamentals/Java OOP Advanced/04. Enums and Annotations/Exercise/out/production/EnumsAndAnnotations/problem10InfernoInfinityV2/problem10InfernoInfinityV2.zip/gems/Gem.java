package problem10InfernoInfinityV2.gems;

public interface Gem {

    int getBonusStrength();
    int getBonusAgility();
    int getBonusVitality();
}
