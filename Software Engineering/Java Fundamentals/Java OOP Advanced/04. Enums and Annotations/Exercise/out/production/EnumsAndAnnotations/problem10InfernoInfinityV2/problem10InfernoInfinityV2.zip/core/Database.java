package problem10InfernoInfinityV2.core;

import problem10InfernoInfinityV2.weapons.Weapon;

public interface Database {

    void addWeapon(Weapon weapon);
    Weapon getWeapon(String name);
}
