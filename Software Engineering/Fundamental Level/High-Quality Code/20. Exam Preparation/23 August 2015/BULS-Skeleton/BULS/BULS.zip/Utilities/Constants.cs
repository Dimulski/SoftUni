﻿namespace BangaloreUniversityLearningSystem.Utilities
{
    public class Constants
    {
        public const string ControllerSuffix = "Controller";

        public const string ViewsFolder = "Views";

        public const string NamespaceSeparator = ".";
    }
}
