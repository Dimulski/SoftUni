﻿namespace LiskovSubstitutionSquareAfter
{
    public abstract class Shape
    {
        public abstract decimal Area { get; }
    }
}
