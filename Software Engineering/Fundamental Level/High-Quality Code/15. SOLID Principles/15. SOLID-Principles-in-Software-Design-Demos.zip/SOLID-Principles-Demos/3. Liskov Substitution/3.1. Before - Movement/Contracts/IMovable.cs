﻿namespace LiskovSubstitutionMovementBefore.Contracts
{
    public interface IMovable
    {
        void Translate();

        void Rotate();

        void Move();
    }
}
