﻿namespace LiskovSubstitutionEmployeesBefore
{
    public class Employee
    {
        public string Name { get; set; }
    }
}
