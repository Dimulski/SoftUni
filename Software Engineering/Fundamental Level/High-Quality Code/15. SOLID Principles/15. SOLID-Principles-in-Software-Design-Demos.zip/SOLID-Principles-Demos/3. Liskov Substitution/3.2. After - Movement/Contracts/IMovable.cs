﻿namespace LiskovSubstitutionMovementAfter.Contracts
{
    public interface IMovable
    {
        void Move();
    }
}
