﻿namespace InterfaceSegregationWorkerBefore
{
    using InterfaceSegregationWorkerBefore.Contracts;

    public class Human : IWorker
    {
        public void Eat()
        {
            // eat
        }

        public void Work()
        {
            // work
        }

        public void Sleep()
        {
            // sleep
        }
    }
}
