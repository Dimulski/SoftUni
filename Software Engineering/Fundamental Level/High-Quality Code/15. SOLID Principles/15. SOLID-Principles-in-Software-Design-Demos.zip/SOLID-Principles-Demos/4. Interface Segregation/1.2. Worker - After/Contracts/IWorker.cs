﻿namespace InterfaceSegregationWorkerAfter.Contracts
{
    public interface IWorker
    {
        void Work();
    }
}
