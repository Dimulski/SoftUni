﻿namespace InterfaceSegregationWorkerAfter.Contracts
{
    public interface IEater
    {
        void Eat();
    }
}
