﻿namespace DependencyInversionWorkerAfter
{
    using DependencyInversionWorkerAfter.Contracts;

    public class Worker : IWorker
    {
        public void Work()
        {
            // do the work
        }
    }
}
