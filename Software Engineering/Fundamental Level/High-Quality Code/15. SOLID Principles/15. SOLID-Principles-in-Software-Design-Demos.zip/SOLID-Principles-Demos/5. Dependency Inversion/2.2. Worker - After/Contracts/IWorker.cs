﻿namespace DependencyInversionWorkerAfter.Contracts
{
    public interface IWorker
    {
        void Work();
    }
}
