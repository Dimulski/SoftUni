﻿namespace OpenClosedDrawingShapesBefore
{
    using OpenClosedDrawingShapesBefore.Contracts;

    public class Circle : IShape
    {
    }
}
