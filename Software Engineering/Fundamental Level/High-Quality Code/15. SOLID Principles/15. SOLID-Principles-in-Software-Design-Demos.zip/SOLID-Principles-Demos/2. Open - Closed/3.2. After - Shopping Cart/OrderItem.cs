﻿namespace OpenClosedShoppingCartAfter
{
    public class OrderItem
    {
        public string Product { get; set; }

        public int Quantity { get; set; }
    }
}