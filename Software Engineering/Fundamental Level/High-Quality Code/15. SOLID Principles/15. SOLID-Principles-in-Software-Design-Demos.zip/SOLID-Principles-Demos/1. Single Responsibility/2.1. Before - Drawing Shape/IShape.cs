﻿namespace SingleResponsibilityShapesBefore
{
    public interface IShape
    {
        void Draw(IDrawingContext context);
    }
}
