﻿namespace SingleResponsibilityShapesBefore
{
    public interface IDrawingContext
    {
    }
}
