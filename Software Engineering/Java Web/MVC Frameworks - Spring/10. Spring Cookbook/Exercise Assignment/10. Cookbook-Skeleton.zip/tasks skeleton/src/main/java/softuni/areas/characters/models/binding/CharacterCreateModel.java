package softuni.areas.characters.models.binding;

public class CharacterCreateModel {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
