function getCart() {
    //TODO: Implement the method
}

function clearCart() {
    //TODO: Implement the method
}
