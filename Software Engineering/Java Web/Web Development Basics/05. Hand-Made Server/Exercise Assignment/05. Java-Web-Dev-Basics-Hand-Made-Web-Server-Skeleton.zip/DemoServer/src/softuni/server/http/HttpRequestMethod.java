package softuni.server.http;

public enum HttpRequestMethod {
    GET, POST
}
