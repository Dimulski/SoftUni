package softuni.server;


public interface View {
    String view();
}
