package softuni.server;

import java.net.SocketException;

public interface Server {
    void runServer() throws SocketException;

}
