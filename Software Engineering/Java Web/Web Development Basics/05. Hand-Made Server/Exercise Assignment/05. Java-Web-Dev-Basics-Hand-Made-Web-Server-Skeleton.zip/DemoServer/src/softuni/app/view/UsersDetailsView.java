package softuni.app.view;

import softuni.server.View;

/**
 * Created by s_she on 09.2.2017 г..
 */
public class UsersDetailsView implements View {
    @Override
    public String view() {
        return null;
    }
}
