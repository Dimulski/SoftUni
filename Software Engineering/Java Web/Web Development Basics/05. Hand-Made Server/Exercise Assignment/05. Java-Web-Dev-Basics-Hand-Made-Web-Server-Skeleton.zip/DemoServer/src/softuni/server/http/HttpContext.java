package softuni.server.http;

public interface HttpContext {
    HttpRequest getHttpRequest();
}
