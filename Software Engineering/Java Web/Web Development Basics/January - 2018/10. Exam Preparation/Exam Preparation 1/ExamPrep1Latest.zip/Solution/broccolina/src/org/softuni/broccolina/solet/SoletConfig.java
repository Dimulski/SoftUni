package org.softuni.broccolina.solet;

public interface SoletConfig {
    public Object getAttribute(String attributeName);

    public void setAttribute(String key, Object value);
}
