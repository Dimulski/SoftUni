package controllers;

import bindingModels.UserLoginBindingModel;
import bindingModels.UserRegisterBindingModel;
import entities.User;
import org.softuni.broccolina.solet.HttpSoletRequest;
import org.softuni.summer.api.Controller;
import org.softuni.summer.api.GetMapping;
import org.softuni.summer.api.PostMapping;
import repositories.UserRepository;

@Controller
public class UserController {

    private UserRepository userRepository;

    public UserController() {
        this.userRepository = new UserRepository();
    }

    @GetMapping(route = "/login")
    public String login(HttpSoletRequest request) {
        if (this.isLoggedIn(request)) {
            return "redirect:/";
        }

        return "template:login";
    }

    @PostMapping(route = "/login")
    public String loginConfirm(HttpSoletRequest request, UserLoginBindingModel userLoginBindingModel) {
        if (this.isLoggedIn(request)) {
            return "redirect:/";
        }

        User registeredUser = this.userRepository.findByUsername(userLoginBindingModel.getUsername());
        if (registeredUser == null || !registeredUser.getPassword().equals(userLoginBindingModel.getPassword())) {
            return "redirect:/login";
        }

        request.getSession().addAttribute("user-id", registeredUser.getId());
        request.getSession().addAttribute("username", registeredUser.getUsername());

        return "redirect:/";
    }

    @GetMapping(route = "/register")
    public String register(HttpSoletRequest request) {
        if (this.isLoggedIn(request)) {
            return "redirect:/";
        }

        return "template:register";
    }

    @PostMapping(route = "/register")
    public String registerConfirm(HttpSoletRequest request, UserRegisterBindingModel userRegisterBindingModel) {
        if (this.isLoggedIn(request)) {
            return "redirect:/";
        }

        if (!userRegisterBindingModel.getPassword().equals(userRegisterBindingModel.getConfirmPassword())) {
            return "redirect:/register";
        }

        if (this.userRepository.findByUsername(userRegisterBindingModel.getUsername()) != null) {
            return "redirect:/register";
        }

        User user = new User();
        user.setUsername(userRegisterBindingModel.getUsername());
        user.setPassword(userRegisterBindingModel.getPassword());
        user.setEmail(userRegisterBindingModel.getEmail());

        this.userRepository.createUser(user);

        return "redirect:/login";
    }

    @GetMapping(route = "/logout")
    public String logout(HttpSoletRequest request) {
        if (!this.isLoggedIn(request)) {
            return "redirect:/login";
        }

        request.getSession().invalidate();

        return "redirect:/";
    }

    private boolean isLoggedIn(HttpSoletRequest request) {
        return request.getSession().getAttributes().containsKey("user-id");
    }
}
