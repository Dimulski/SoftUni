package controllers;

import bindingModels.KittenCreateBindingModel;
import entities.Kitten;
import entities.KittenBreed;
import org.softuni.broccolina.solet.HttpSoletRequest;
import org.softuni.summer.api.Controller;
import org.softuni.summer.api.GetMapping;
import org.softuni.summer.api.Model;
import org.softuni.summer.api.PostMapping;
import repositories.KittenRepository;

@Controller
public class KittenController {

    private KittenRepository kittenRepository;

    public KittenController() {
        this.kittenRepository = new KittenRepository();
    }

    @GetMapping(route = "/kittens/all")
    public String allKittens(HttpSoletRequest request, Model model) {
        if (!this.isLoggedIn(request)) {
            return "redirect:/login";
        }

        Kitten[] allKittens = this.kittenRepository.allKittens();

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < allKittens.length; i++) {
            Kitten currentKitten = allKittens[i];

            if (i == 0) {
                result
                        .append("<div class=\"row\">")
                        .append(currentKitten.toString());
            } else if (i % 3 == 0) {
                result
                        .append("</div>")
                        .append()
            } else {

            }
        }

        model.addAttribute("allkittens", result);

        return "template:all-kittens";
    }

    @GetMapping(route = "/kittens/add")
    public String addKitten(HttpSoletRequest request) {
        if (!this.isLoggedIn(request)) {
            return "redirect:/login";
        }

        return "template:add-kitten";
    }

    @PostMapping(route = "/kittens/add")
    public String addKittenConfirm(HttpSoletRequest request, KittenCreateBindingModel kittenCreateBindingModel) {
        if (!this.isLoggedIn(request)) {
            return "redirect:/login";
        }

        Kitten kitten = new Kitten();

        kitten.setName(kittenCreateBindingModel.getName());
        kitten.setAge(kittenCreateBindingModel.getAge());
        kitten.setBreed(KittenBreed.parseValue(kittenCreateBindingModel.getBreed()));

        this.kittenRepository.createKitten(kitten);

        return "redirect:/kittens/all";
    }

    private boolean isLoggedIn(HttpSoletRequest request) {
        return request.getSession().getAttributes().containsKey("user-id");
    }
}
