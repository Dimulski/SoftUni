package repositories;

public interface RepositoryInvoker {
    void invoke(RepositoryActionResult actionResult);
}
