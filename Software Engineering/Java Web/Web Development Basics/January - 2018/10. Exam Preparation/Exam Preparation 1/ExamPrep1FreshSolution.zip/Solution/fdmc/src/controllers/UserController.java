package controllers;

import org.softuni.broccolina.solet.HttpSoletRequest;
import org.softuni.summer.api.Controller;
import org.softuni.summer.api.GetMapping;

@Controller
public class UserController {

    @GetMapping(route = "/login")
    public String login(HttpSoletRequest request) {

        return "template:login";
    }

    @GetMapping(route = "/register")
    public String register() {
        return "template:register";
    }
}
