package org.softuni.main.javache.http;

public interface HttpContext {
    HttpRequest getHttpRequest();

    HttpResponse getHttpResponse();
}
