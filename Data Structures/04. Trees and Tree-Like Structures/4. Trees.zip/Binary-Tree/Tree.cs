﻿using System;
using System.Collections.Generic;

public class Tree<T>
{
    public Tree(T value, params Tree<T>[] children)
    {
      // TODO
    }

    public void Print(int indent = 0)
    {
        // TODO
    }

    public void Each(Action<T> action)
    {
        // TODO
    }
}
