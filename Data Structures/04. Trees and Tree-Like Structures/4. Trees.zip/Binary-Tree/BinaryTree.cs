﻿using System;

public class BinaryTree<T>
{
    public BinaryTree(T value, BinaryTree<T> leftChild = null, BinaryTree<T> rightChild = null)
    {
        // TODO
    }

    public void PrintIndentedPreOrder(int indent = 0)
    {
        // TODO
    }

    public void EachInOrder(Action<T> action)
    {
        // TODO
    }

    public void EachPostOrder(Action<T> action)
    {
        // TODO
    }
}
