﻿namespace P03_CalculateArithmeticExpression.Operations
{
    public interface IOperation
    {
        double Calculate(params double[] p);
    }
}