﻿Aho–Corasick string matching algorithm C# implementation



FROM: http://code.google.com/p/libanculus-sharp/