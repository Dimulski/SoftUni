﻿namespace Pr4_OrderedSet
{
    public class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
