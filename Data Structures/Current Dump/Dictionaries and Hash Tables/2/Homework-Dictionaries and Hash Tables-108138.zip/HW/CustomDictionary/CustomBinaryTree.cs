﻿namespace CustomDictionary
{
    public class CustomBinaryTree<T>
    {
        
    }
}
