﻿namespace AvlTreeLab
{
    public class Node<T>
    {
    }
}

