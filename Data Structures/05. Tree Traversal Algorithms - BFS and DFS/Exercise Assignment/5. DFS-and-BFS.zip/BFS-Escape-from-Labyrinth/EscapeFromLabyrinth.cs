﻿public class EscapeFromLabyrinth
{
    public static void Main()
    {
        // TODO: implement me
    }
}
