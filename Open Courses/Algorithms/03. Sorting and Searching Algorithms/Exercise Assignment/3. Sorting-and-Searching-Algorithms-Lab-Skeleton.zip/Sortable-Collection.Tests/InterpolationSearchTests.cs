﻿namespace Sortable_Collection.Tests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class InterpolationSearchTests
    {
        [TestMethod]
        // TODO: Rename test method
        public void TestMethod1()
        {
            // TODO: Add test logic here
        }
    }
}
