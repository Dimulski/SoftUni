namespace Kurskal
{
    using System;
    using System.Collections.Generic;

    public class KruskalAlgorithm
    {
        public static List<Edge> Kruskal(int numberOfVertices, List<Edge> edges)
        {
            throw new NotImplementedException();
        }

        public static int FindRoot(int node, int[] parent)
        {
            throw new NotImplementedException();
        }
    }
}
