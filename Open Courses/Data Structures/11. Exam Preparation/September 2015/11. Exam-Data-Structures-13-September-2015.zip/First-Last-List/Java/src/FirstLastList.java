public class FirstLastList<T extends Comparable<T>>
implements IFirstLastList<T> {

	@Override
	public void add(T element) {
		// TODO Auto-generated method stub		
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Iterable<T> first(int count) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<T> last(int count) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<T> min(int count) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<T> max(int count) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub	
	}

	@Override
	public int removeAll(T element) {
		// TODO Auto-generated method stub
		return 0;
	}
}
