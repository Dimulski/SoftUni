﻿namespace QuadTree.Core
{
    public interface IBoundable
    {
        Rectangle Bounds { get; set; }
    }
}
