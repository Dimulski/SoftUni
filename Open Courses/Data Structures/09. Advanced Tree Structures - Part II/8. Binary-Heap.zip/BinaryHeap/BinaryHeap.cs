﻿using System;

public class BinaryHeap<T> where T : IComparable<T>
{
    public BinaryHeap()
    {
        // TODO
    }

    public BinaryHeap(T[] elements)
    {
        // TODO
    }

    public int Count
    {
        get
        {
            // TODO
            throw new NotImplementedException();
        }
    }

    public T ExtractMax()
    {
        // TODO
        throw new NotImplementedException();
    }

    public T PeekMax()
    {
        // TODO
        throw new NotImplementedException();
    }

    public void Insert(T node)
    {
        // TODO
    }

    private void HeapifyDown(int i)
    {
        // TODO
    }

    private void HeapifyUp(int i)
    {
        // TODO
    }
}
